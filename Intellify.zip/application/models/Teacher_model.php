<?php

Class Teacher_model extends CI_model{

	public function create($formArray){
		$this->db->insert('student',$formArray);

		return $id=$this->db->insert_id();
	}	

	public function all()
	{
		$result=$this->db->order_by('id','ASC')->get('student')->result_array();

		return $result;
	}

	function getrow($id)
	{
		$this->db->where('id',$id);
		$row= $this->db->get('student')->row_array();

		return $row;
	}

	function update($id,$formArray)
	{
		$this->db->where('id',$id);
		$this->db->update('student',$formArray);

		return $id;
	}

	function delete($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('student');
	}

}

?>
<tr id="row-<?php echo $row['S_ID'] ?>">
	<td class="modalS_id"><?php echo $row['S_ID'] ?></td>
	<td class="modalt_id"><?php echo $row['T_ID'] ?></td>
	<td class="modalS_Name"><?php echo $row['S_Name'] ?></td>
	<td class="modalS_Contact"><?php echo $row['S_Contact'] ?></td>
	<td class="modalSchool"><?php echo $row['School'] ?></td>
	<td class="modaldate"><?php echo $row['Date'] ?></td>
	<td>
		<a href="javascript:void(0);" onclick="showEditForm(<?php echo $row['id'] ?>);" class="btn btn-primary">Edit</a>
	</td>
	<td>
		<a href="javascript:void(0);" onclick="confirmdeletemodel(<?php echo $row['id'] ?>);" class="btn btn-danger">Delete</a>
	</td>
</tr>
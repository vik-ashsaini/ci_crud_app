<?php 

class Teacher extends CI_controller{

	function index()
	{
		$this->load->model('Teacher_model');
		$rows=$this->Teacher_model->all();
		$data['rows']=$rows;
		$this->load->view('Teacher_model/list.php',$data);
	}

	function showcreateform()
	{
		$html=$this->load->view('Teacher_model/create.php','',true);
		$response['html']=$html;
		echo json_encode($response);

	}

	function saveModel()
	{
		$this->load->model('Teacher_model');

		$this->load->library('form_validation');
		$this->form_validation->set_rules('S_ID','S_ID','required');
		$this->form_validation->set_rules('T_ID','T_ID','required');
		$this->form_validation->set_rules('S_Name','S_Name','required');
		$this->form_validation->set_rules('S_Contact','S_Contact','required');
		$this->form_validation->set_rules('School','School','required');
		// $this->form_validation->set_rules('Date','Date','required');

		if($this->form_validation->run() == true)
		{
			$formArray=array();
			$formArray['S_ID']=$this->input->post('S_ID');
			$formArray['T_ID']=$this->input->post('T_ID');
			$formArray['S_Name']=$this->input->post('S_Name');
			$formArray['S_Contact']=$this->input->post('S_Contact');
			$formArray['School']=$this->input->post('School');
			$formArray['Date']=date('Y-m-d H:i:s');


			$id=$this->Teacher_model->create($formArray);
			
			$row=$this->Teacher_model->getrow($id);
			$vdata['row']=$row;
			$rowhtml=$this->load->view('Teacher_model/view',$vdata,true);

			$response['row']=$rowhtml;
			$response['status']=1;
			$response['message']="<div class=\"alert alert-success\">Student has been added Successfully</div>";
		}
		else
		{
			$response['status']=0;
			$response['S_ID']=strip_tags(form_error('S_ID'));
			$response['T_ID']=strip_tags(form_error('T_ID'));
			$response['S_Name']=strip_tags(form_error('S_Name'));
			$response['S_Contact']=strip_tags(form_error('S_Contact'));
			$response['School']=strip_tags(form_error('School'));
			// $response['Date']=strip_tags(form_error('Date'));
		}
		echo json_encode($response);
	}

	function getstudentmodel($id)
	{
		$this->load->model('Teacher_model');
		$row=$this->Teacher_model->getrow($id);

		$data['row']=$row;
		$html=$this->load->view('Teacher_model/edit.php',$data,true);
		$response['html']=$html;
		echo json_encode($response);
	}


	function updateModel()
	{

		$this->load->model('Teacher_model');
		$id=$this->input->post['id'];
		$row=$this->Teacher_model->getrow($id);
		if(empty($row))
		{
			$response['message']="Record deleted";
			$response['status']=100;
			json_encode($response);
			exit;
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('S_ID','S_ID','required');
		$this->form_validation->set_rules('T_ID','T_ID','required');
		$this->form_validation->set_rules('S_Name','S_Name','required');
		$this->form_validation->set_rules('S_Contact','S_Contact','required');
		$this->form_validation->set_rules('School','School','required');

		if($this->form_validation->run() == true)
		{
			$formArray=array();
			$formArray['S_ID']=$this->input->post('S_ID');
			$formArray['T_ID']=$this->input->post('T_ID');
			$formArray['S_Name']=$this->input->post('S_Name');
			$formArray['S_Contact']=$this->input->post('S_Contact');
			$formArray['School']=$this->input->post('School');
			$formArray['Date']=date('Y-m-d H:i:s');


			$id=$this->Teacher_model->update($id,$formArray);
			
			$row=$this->Teacher_model->getrow($id);

			$response['row']=$row;
			$response['status']=1;
			$response['message']="<div class=\"alert alert-success\">Student has been Updated Successfully</div>";
		}
		else
		{
			$response['status']=0;
			$response['S_ID']=strip_tags(form_error('S_ID'));
			$response['T_ID']=strip_tags(form_error('T_ID'));
			$response['S_Name']=strip_tags(form_error('S_Name'));
			$response['S_Contact']=strip_tags(form_error('S_Contact'));
			$response['School']=strip_tags(form_error('School'));
		}
		echo json_encode($response);
	}

	function deletemodal($id)
	{
		$this->load->model('Teacher_model');
		$row=$this->Teacher_model->getrow($id);
		if(empty($row))
		{
			$response['message']="Record already deleted";
			$response['status']=0;
			echo  json_encode($response);
			exit;
		}
		else
		{
			$this->Teacher_model->delete($id); 
			$response['message']="Record has been deleted Successfully";
			$response['status']=1;
			echo json_encode($response); 
		}
	}
}

	
?>
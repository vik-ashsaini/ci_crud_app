<!DOCTYPE html>
<html>
<head>
	<title>Teacher View</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assests/css/bootstrap.min.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assests/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assests/css/style.css">
	
</head>
<body>
	<div class="header">
		<div class="container">
			<h1 class="heading">Teacher Application</h1>
		</div>
	</div>
	<div class="container">
		<div class="row pt-4">
			<div class="col-md-6">
				<h4>Students</h4>
			</div>
			<div class="col-md-6 text-right">
				<a href="javascript:void(0);" onclick="showModal();" class="btn btn-primary">Create</a>
			</div>

			<div class="col-md-12 pt-3">
				<table class="table table-striped" id="studentlist">
					<tr>
						<th>S_ID</th>
						<th>T_ID</th>
						<th>S_Name</th>
						<th>S_Contact</th>
						<th>School</th>
						<th>Date and Time of Register</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>

				<?php if(!empty($rows)) {
						foreach ($rows as $row) 
						{ 
							$data['row']=$row;
							$this->load->view('Teacher_model/view',$data);	# code...
						}	 
					} 
					else
					{ 
				?>
						<tr>
							<td>Records Not Found </td>
						</tr>
				<?php }  ?>

				</table>
			</div>
		</div>
	</div>



<!-- Modal -->
<div class="modal fade" id="createstudent" tabindex="-1" role="dialog"  aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
    	<div class="modal-content">
    		<div class="modal-header">
        		<h5 class="modal-title" id="modal-title" id="exampleModalCenterTitle">Create</h5>
        		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          			<span aria-hidden="true">&times;</span>
        		</button>
      		</div>
      		<div id="response">
      			 
      		</div>

      		<!-- <div class="modal-footer">
			    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			    <button type="button" class="btn btn-primary">Submit</button>
			</div> -->
    	</div>
  	</div>
</div>

<div class="modal fade" id="ajaxResponseModal" tabindex="-1" role="dialog"  aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
    	<div class="modal-content">
    		<div class="modal-header">
        		<h5 class="modal-title" id="modal-title" id="exampleModalCenterTitle">Alert</h5>
        		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          			<span aria-hidden="true">&times;</span>
        		</button>
      		</div>
      		<div id="ajaxResponse">
      			<div class="modal-body">
		      		<div class="modal-footer">
					    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
    	</div>
  	</div>
</div>

<div class="modal fade" id="deletestudent" tabindex="-1" role="dialog"  aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
    	<div class="modal-content">
    		<div class="modal-header">
        		<h5 class="modal-title" id="modal-title" id="exampleModalCenterTitle">Delete</h5>
        		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          			<span aria-hidden="true">&times;</span>
        		</button>
      		</div>
      		<div id="ajaxResponse">
      			<div class="modal-body">
		      		<div class="modal-footer">
					    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					    <button type="button" onclick="deletenow();" class="btn btn-danger">Yes</button>
					</div>
				</div>
			</div>

      		<div class="modal-footer">
			    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			    <button type="button" onclick="deletenow();" class="btn btn-danger">Yes</button>
			</div>
    	</div>
  	</div>
</div>



<script type="text/javascript">

	function showModal()
	{
		$("#createstudent").modal("show");
		$("#createstudent .modal-title").html('Create');
		$.ajax({
			url:'<?php echo base_url().'index.php/Teacher/showcreateform'?>',
			type:'POST',
			data:{},
			dataType:'json',
			success:function(response){
				// console.log(response);
				$("#response").html(response["html"]);
			}
		});
	}

	$("body").on("submit", "#createstudentmodal",function(e){
		e.preventDefault();
	// $("#createstudentmodal").submit(function(e){
	 	// alert();

		$.ajax({
			url:'<?php echo base_url().'index.php/Teacher/saveModel'?>',
			type:'POST',
			data:$(this).serializeArray(),
			dataType:'json',
			success:function(response){
				
				if(response['status'] == 0)
				{
					if(response['S-id']!="")
					{
						$(".siderror").html(response["sid"]).addClass('invalid-feedback d-block');
						$("#S-id").addClass('is-invalid');
					}
					else
					{
						$(".siderror").html("").removeClass('invalid-feedback d-block');
						$("#S-id").removeClass('is-invalid');
					}
					
				} 
				else
				{
					$("#createstudent").modal("hide");
					$("#ajaxResponseModal .modal-body").html(response["message"]);
					$("#ajaxResponseModal").modal("Show");

					$(".siderror").html("").removeClass('invalid-feedback d-block');
					$("#S-id").removeClass('is-invalid');


					$("#studentlist").append(response["row"]);
				}
			}
		});
	});

	function showEditForm(id)
	{
		$("#createstudent .modal-title").html('Edit');
		$.ajax({
			url:'<?php echo base_url().'index.php/Teacher/getstudentmodel/'?>'+id,
			type:'POST',
			dataType:'json',
			success:function(response){
				$("#createstudent #response").html(response["html"]);
				$("#createstudent").modal("show");
			}
		});
	}


	$("body").on("submit", "#editstudentmodal",function(e){
		e.preventDefault();
	// $("#createstudentmodal").submit(function(e){
	 	// alert();

		$.ajax({
			url:'<?php echo base_url().'index.php/Teacher/updateModel'?>',
			type:'POST',
			data:$(this).serializeArray(),
			dataType:'json',
			success:function(response){
				
				if(response['status'] == 0)
				{
					if(response['S_ID']!="")
					{
						$(".s_iderror").html(response["S_ID"]).addClass('invalid-feedback d-block');
						$("#S_ID").addClass('is-invalid');
					}
					else
					{
						$(".s_iderror").html("").removeClass('invalid-feedback d-block');
						$("#S_ID").removeClass('is-invalid');
					}
					if(response['T_ID']!="")
					{
						$(".t_iderror").html(response["T_ID"]).addClass('invalid-feedback d-block');
						$("#T_ID").addClass('is-invalid');
					}
					else
					{
						$(".t_iderror").html("").removeClass('invalid-feedback d-block');
						$("#T_ID").removeClass('is-invalid');
					}
					if(response['S_Name']!="")
					{
						$(".s_nameerror").html(response["S_Name"]).addClass('invalid-feedback d-block');
						$("#S_Name").addClass('is-invalid');
					}
					else
					{
						$(".s_nameerror").html("").removeClass('invalid-feedback d-block');
						$("#S_Name").removeClass('is-invalid');
					}
					if(response['S_Contact']!="")
					{
						$(".s_contacterror").html(response["S_Contact"]).addClass('invalid-feedback d-block');
						$("#S_Contact").addClass('is-invalid');
					}
					else
					{
						$(".s_contacterror").html("").removeClass('invalid-feedback d-block');
						$("#S_Contact").removeClass('is-invalid');
					}
					if(response['School']!="")
					{
						$(".schoolerror").html(response["School"]).addClass('invalid-feedback d-block');
						$("#School").addClass('is-invalid');
					}
					else
					{
						$(".schoolerror").html("").removeClass('invalid-feedback d-block');
						$("#School").removeClass('is-invalid');
					}
					
				} 
				else
				{
					$("#createstudent").modal("hide");
					$("#ajaxResponseModal .modal-body").html(response["message"]);
					$("#ajaxResponseModal").modal("Show");

					$(".s_iderror").html("").removeClass('invalid-feedback d-block');
					$("#S_ID").removeClass('is-invalid');
					$(".t_iderror").html("").removeClass('invalid-feedback d-block');
					$("#T_ID").removeClass('is-invalid');
					$(".s_nameerror").html("").removeClass('invalid-feedback d-block');
					$("#S_Name").removeClass('is-invalid');
					$(".s_contacterror").html("").removeClass('invalid-feedback d-block');
					$("#S_Contact").removeClass('is-invalid');
					$(".schoolerror").html("").removeClass('invalid-feedback d-block');
					$("#School").removeClass('is-invalid');
					



					var id=response["row"]["id"];
					$("#row-"+id+" .modalS_id").html(response["row"]["S_ID"]);
					$("#row-"+id+" .modalt_id").html(response["row"]["T_ID"]);
					$("#row-"+id+" .modalS_Name").html(response["row"]["S_Name"]);
					$("#row-"+id+" .modalS_Contact").html(response["row"]["S_Contact"]);
					$("#row-"+id+" .modalSchool").html(response["row"]["School"]);
					$("#row-"+id+" .modaldate").html(response["row"]["Date"]);
				}
			}
		});
	});

	function confirmdeletemodel(id){
		$("#deletestudent").modal('show');
		$("#createstudent .modal-body").html('Are you sure to delete!');
		$("#deletestudent").data("id",id);

		alert();
	}

	function deletenow(id){
		var id =$("#deletestudent").data('id');

		$.ajax({
			url:'<?php echo base_url().'index.php/Teacher/deletemodal/'?>'+id,
			type:'POST',
			data:$(this).serializeArray(),
			dataType:'json',
			success:function(response){
				if(response['status'] == 0)
				{
					$("#deletestudent").modal('hide');
					$("#ajaxResponseModal .modal-body").html(response["message"]);
					$("#ajaxResponseModal").modal("Show");
				}
				else
				{
					$("#deletestudent").modal('hide');
					$("#ajaxResponseModal .modal-body").html(response["message"]);
					$("#ajaxResponseModal").modal("Show");
				}
			}
		});
	}

</script>
</body>
</html>
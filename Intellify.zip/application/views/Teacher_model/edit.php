<form action="" method="post" id="editstudentmodal" name="editstudentmodal">
	<input type="hidden" name="id" value="<?php echo $row['id'] ?>">
	<div class="modal-body">
		<div class="form-group">
			<label>S_ID</label>
			<input type="text" name="S_ID" value="<?php echo $row['S_ID'] ?>" class="form-control">
			<p class="siderror"></p>
		</div>
		<div class="form-group">
			<label>T_ID</label>
			<input type="text" name="T_id" value="<?php echo $row['T_ID'] ?>" class="form-control">
		</div>
		<div class="form-group">
			<label>S_Name</label>
			<input type="text" name="S_Name" value="<?php echo $row['S_Name'] ?>" class="form-control" placeholder="Student Name">
		</div>
		<div class="form-group">
			<label>S_Contact</label>
			<input type="text" name="S_Contact" value="<?php echo $row['S_Contact'] ?>" class="form-control">
		</div>
		<div class="form-group">
			<label>School</label>
			<input type="text" name="School" value="<?php echo $row['School'] ?>" class="form-control">
		</div>
		<div class="form-group">
			<label>Date and Time </label>
			<input type="text" name="date" value="<?php echo $row['Date'] ?>" class="form-control">
		</div>
	</div>
	<div class="modal-footer">
	    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	    <button type="submit" class="btn btn-primary">Submit</button>
	</div>
</form>

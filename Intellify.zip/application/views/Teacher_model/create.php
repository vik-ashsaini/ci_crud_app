<form action="" method="post" id="createstudentmodal" name="createstudentmodal">
	<div class="modal-body">
		<div class="form-group">
			<label>S_ID</label>
			<input type="text" name="S_ID" value="" class="form-control">
			<p class="s_iderror"></p>
		</div>
		<div class="form-group">
			<label>T_ID</label>
			<input type="text" name="T_ID" value="" class="form-control">
			<p class="t_iderror"></p>
		</div>
		<div class="form-group">
			<label>S_Name</label>
			<input type="text" name="S_Name" value="" class="form-control" placeholder="Student Name">
			<p class="s_nameerror"></p>
		</div>
		<div class="form-group">
			<label>S_Contact</label>
			<input type="text" name="S_Contact" value="" class="form-control">
			<p class="s_contacterror"></p>
		</div>
		<div class="form-group">
			<label>School</label>
			<input type="text" name="School" value="" class="form-control">
			<p class="schoolerror"></p>
		</div>
		<!-- <div class="form-group">
			<label>Date and Time </label>
			<input type="text" name="date" value="" class="form-control">
		</div> -->
	</div>
	<div class="modal-footer">
	    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	    <button type="submit" class="btn btn-primary">Submit</button>
	</div>
</form>
